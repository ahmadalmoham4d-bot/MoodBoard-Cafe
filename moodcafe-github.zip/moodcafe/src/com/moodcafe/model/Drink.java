package com.moodcafe.model;

public class Drink {
    private final String name;
    private final String description;
    private final String emoji;
    private final String color;
    private final String ingredients;
    private final String mood;

    public Drink(String name, String description, String emoji, String color, String ingredients, String mood) {
        this.name = name;
        this.description = description;
        this.emoji = emoji;
        this.color = color;
        this.ingredients = ingredients;
        this.mood = mood;
    }

    public String getName()        { return name; }
    public String getDescription() { return description; }
    public String getEmoji()       { return emoji; }
    public String getColor()       { return color; }
    public String getIngredients() { return ingredients; }
    public String getMood()        { return mood; }

    /** Serialize to a simple JSON string */
    public String toJson() {
        return String.format(
            "{\"name\":\"%s\",\"description\":\"%s\",\"emoji\":\"%s\",\"color\":\"%s\",\"ingredients\":\"%s\",\"mood\":\"%s\"}",
            esc(name), esc(description), esc(emoji), esc(color), esc(ingredients), esc(mood)
        );
    }

    private String esc(String s) {
        return s.replace("\\","\\\\").replace("\"","\\\"");
    }
}

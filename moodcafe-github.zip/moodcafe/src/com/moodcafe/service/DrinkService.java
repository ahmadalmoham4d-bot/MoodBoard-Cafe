package com.moodcafe.service;

import com.moodcafe.model.Drink;
import java.util.*;

public class DrinkService {

    private static final DrinkService INSTANCE = new DrinkService();
    public static DrinkService getInstance() { return INSTANCE; }

    private final Map<String, List<Drink>> moodDrinks = new LinkedHashMap<>();

    private DrinkService() {
        moodDrinks.put("happy", Arrays.asList(
            new Drink("Sunshine Burst",   "A fizzy mango-passion fruit blend that tastes like a tropical vacation",      "🥭", "#FFB347", "Mango juice, passion fruit, sparkling water, honey, lime", "happy"),
            new Drink("Berry Fiesta",     "Wild berry explosion with a hint of mint — pure joy in a glass",              "🫐", "#9B59B6", "Blueberries, raspberries, strawberries, mint, lemon juice",  "happy"),
            new Drink("Golden Hour Latte","Warm turmeric latte with oat milk and a pinch of cinnamon magic",             "✨", "#F4A460", "Turmeric, oat milk, cinnamon, honey, ginger",                "happy")
        ));
        moodDrinks.put("sad", Arrays.asList(
            new Drink("Warm Hug Cocoa",    "Rich dark chocolate with a swirl of cream — like a blanket in a mug",       "🍫", "#6B3A2A", "Dark cocoa powder, whole milk, brown sugar, vanilla, whipped cream", "sad"),
            new Drink("Chamomile Dreams",  "Calming chamomile with lavender and honey — gentle and soothing",           "🌸", "#D4A0C0", "Chamomile tea, dried lavender, honey, warm water, lemon",            "sad"),
            new Drink("Midnight Berry",    "Deep, rich smoothie — earthy blueberries and black cherries",               "🫐", "#4A235A", "Black cherries, blueberries, dark grape juice, banana, almond milk",  "sad")
        ));
        moodDrinks.put("energetic", Arrays.asList(
            new Drink("Thunder Citrus",  "Maximum vitamin C punch — grapefruit, orange and cayenne",                    "⚡", "#FF4500", "Grapefruit juice, orange juice, cayenne pepper, lemon, ice",        "energetic"),
            new Drink("Matcha Rocket",   "Premium matcha with espresso — the ultimate double energy boost",             "🍵", "#2D8A4E", "Matcha powder, espresso shot, oat milk, honey",                     "energetic"),
            new Drink("Watermelon Spark","Electrolyte-rich watermelon juice with basil seeds and lime zest",            "🍉", "#FF6B6B", "Fresh watermelon, lime, basil seeds, sea salt, sparkling water",    "energetic")
        ));
        moodDrinks.put("stressed", Arrays.asList(
            new Drink("Zen Garden Tea",  "A grounding blend of ashwagandha, green tea and lemon balm for calm clarity", "🍃", "#5F8A5E", "Green tea, ashwagandha powder, lemon balm, honey, warm water",      "stressed"),
            new Drink("Lavender Cloud",  "Creamy lavender latte to melt away tension and soften the edges",            "💜", "#B39DDB", "Lavender syrup, steamed milk, vanilla, espresso, foam",             "stressed"),
            new Drink("Cool Mint Reset", "Ice-cold peppermint and cucumber water — crisp clarity in every sip",        "🌿", "#00BFA5", "Cucumber, fresh mint, cold water, lime juice, ice",                 "stressed")
        ));
        moodDrinks.put("romantic", Arrays.asList(
            new Drink("Rose Petal Kiss",     "Delicate rose water, lychee and pomegranate — elegant and sweet",        "🌹", "#E91E8C", "Rose water, lychee juice, pomegranate, honey, sparkling water",     "romantic"),
            new Drink("Velvet Strawberry",   "Silky strawberry smoothie with dark chocolate and vanilla cream",        "🍓", "#C2185B", "Fresh strawberries, dark chocolate, vanilla yogurt, honey, cream",  "romantic"),
            new Drink("Sunset Sangria",      "Layered cranberry-orange mocktail that glows like the evening sky",      "🌅", "#FF7043", "Cranberry juice, orange juice, grenadine, ginger ale, fruit slices","romantic")
        ));
        moodDrinks.put("adventurous", Arrays.asList(
            new Drink("Spiced Tamarind",   "Bold tamarind and chili — an unexpected journey for your taste buds",      "🌶️", "#8B4513", "Tamarind paste, chili salt, lime, sugar, sparkling water",           "adventurous"),
            new Drink("Blue Lagoon",       "Vibrant electric-blue drink that looks like it's from another planet",     "🔵", "#0288D1", "Blue spirulina powder, coconut water, pineapple, lime, ice",         "adventurous"),
            new Drink("Smoky Hibiscus",    "Earthy hibiscus with a smoky edge — complex and unforgettable",           "🌺", "#AD1457", "Hibiscus tea, smoked sea salt, lime, honey, club soda",              "adventurous")
        ));
    }

    public List<String> getAllMoods() {
        return new ArrayList<>(moodDrinks.keySet());
    }

    public List<Drink> getDrinksForMood(String mood) {
        return moodDrinks.getOrDefault(mood.toLowerCase(), Collections.emptyList());
    }

    public Drink getRandomDrinkForMood(String mood) {
        List<Drink> drinks = getDrinksForMood(mood);
        if (drinks.isEmpty()) return null;
        return drinks.get(new Random().nextInt(drinks.size()));
    }

    public Map<String, List<Drink>> getAllDrinks() {
        return moodDrinks;
    }

    /** Serialize all moods as a JSON array */
    public String moodsToJson() {
        StringBuilder sb = new StringBuilder("[");
        List<String> moods = getAllMoods();
        for (int i = 0; i < moods.size(); i++) {
            sb.append("\"").append(moods.get(i)).append("\"");
            if (i < moods.size() - 1) sb.append(",");
        }
        sb.append("]");
        return sb.toString();
    }

    /** Serialize a list of drinks as a JSON array */
    public String drinksToJson(List<Drink> drinks) {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < drinks.size(); i++) {
            sb.append(drinks.get(i).toJson());
            if (i < drinks.size() - 1) sb.append(",");
        }
        sb.append("]");
        return sb.toString();
    }
}

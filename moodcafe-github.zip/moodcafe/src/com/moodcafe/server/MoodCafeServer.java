package com.moodcafe.server;

import com.moodcafe.model.Drink;
import com.moodcafe.service.DrinkService;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.io.*;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.List;

/**
 * Pure-Java HTTP server for MoodBoard Café.
 * No external dependencies — uses com.sun.net.httpserver built into the JDK.
 */
public class MoodCafeServer {

    private static final int PORT = 8080;
    private static final DrinkService service = DrinkService.getInstance();

    public static void main(String[] args) throws IOException {
        HttpServer server = HttpServer.create(new InetSocketAddress(PORT), 0);

        // Static assets
        server.createContext("/css/",  MoodCafeServer::serveStatic);
        server.createContext("/js/",   MoodCafeServer::serveStatic);

        // API endpoints (JSON)
        server.createContext("/api/moods",    MoodCafeServer::apiMoods);
        server.createContext("/api/drinks/",  MoodCafeServer::apiDrinks);
        server.createContext("/api/random/",  MoodCafeServer::apiRandom);
        server.createContext("/api/menu",     MoodCafeServer::apiMenu);

        // Page routes
        server.createContext("/mood/",        MoodCafeServer::moodPage);
        server.createContext("/surprise/",    MoodCafeServer::surprisePage);
        server.createContext("/menu",         MoodCafeServer::menuPage);
        server.createContext("/",             MoodCafeServer::homePage);

        server.setExecutor(null); // default executor
        server.start();
        System.out.println("╔══════════════════════════════════════╗");
        System.out.println("║   ☕  MoodBoard Café is running!      ║");
        System.out.println("║   Open: http://localhost:" + PORT + "         ║");
        System.out.println("╚══════════════════════════════════════╝");
    }

    // ── Page handlers ──────────────────────────────────────────────────────────

    private static void homePage(HttpExchange ex) throws IOException {
        if (!ex.getRequestMethod().equals("GET")) { send405(ex); return; }
        String path = ex.getRequestURI().getPath();
        if (!path.equals("/") && !path.equals("/index.html")) { send404(ex); return; }
        sendHtml(ex, 200, TemplateEngine.homePage(service.getAllMoods()));
    }

    private static void moodPage(HttpExchange ex) throws IOException {
        String mood = ex.getRequestURI().getPath().replace("/mood/", "").trim();
        List<Drink> drinks = service.getDrinksForMood(mood);
        if (drinks.isEmpty()) { send404(ex); return; }
        sendHtml(ex, 200, TemplateEngine.drinksPage(mood, drinks, service.getAllMoods()));
    }

    private static void surprisePage(HttpExchange ex) throws IOException {
        String mood = ex.getRequestURI().getPath().replace("/surprise/", "").trim();
        Drink drink = service.getRandomDrinkForMood(mood);
        sendHtml(ex, 200, TemplateEngine.surprisePage(mood, drink));
    }

    private static void menuPage(HttpExchange ex) throws IOException {
        sendHtml(ex, 200, TemplateEngine.menuPage(service.getAllDrinks()));
    }

    // ── API handlers ──────────────────────────────────────────────────────────

    private static void apiMoods(HttpExchange ex) throws IOException {
        sendJson(ex, 200, service.moodsToJson());
    }

    private static void apiDrinks(HttpExchange ex) throws IOException {
        String mood = ex.getRequestURI().getPath().replace("/api/drinks/", "").trim();
        sendJson(ex, 200, service.drinksToJson(service.getDrinksForMood(mood)));
    }

    private static void apiRandom(HttpExchange ex) throws IOException {
        String mood = ex.getRequestURI().getPath().replace("/api/random/", "").trim();
        Drink d = service.getRandomDrinkForMood(mood);
        sendJson(ex, 200, d != null ? d.toJson() : "null");
    }

    private static void apiMenu(HttpExchange ex) throws IOException {
        StringBuilder sb = new StringBuilder("{");
        var all = service.getAllDrinks();
        int i = 0;
        for (var entry : all.entrySet()) {
            sb.append("\"").append(entry.getKey()).append("\":").append(service.drinksToJson(entry.getValue()));
            if (++i < all.size()) sb.append(",");
        }
        sb.append("}");
        sendJson(ex, 200, sb.toString());
    }

    // ── Static file server ────────────────────────────────────────────────────

    private static void serveStatic(HttpExchange ex) throws IOException {
        String uri  = ex.getRequestURI().getPath();          // e.g. /css/style.css
        String base = System.getProperty("user.dir");        // working directory
        Path   file = Paths.get(base, "static" + uri);

        if (!Files.exists(file)) { send404(ex); return; }

        String mime = uri.endsWith(".css")  ? "text/css" :
                      uri.endsWith(".js")   ? "application/javascript" :
                      uri.endsWith(".png")  ? "image/png" :
                      uri.endsWith(".ico")  ? "image/x-icon" : "text/plain";

        byte[] data = Files.readAllBytes(file);
        ex.getResponseHeaders().set("Content-Type", mime);
        ex.sendResponseHeaders(200, data.length);
        try (OutputStream os = ex.getResponseBody()) { os.write(data); }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private static void sendHtml(HttpExchange ex, int code, String html) throws IOException {
        byte[] data = html.getBytes(StandardCharsets.UTF_8);
        ex.getResponseHeaders().set("Content-Type", "text/html; charset=UTF-8");
        ex.sendResponseHeaders(code, data.length);
        try (OutputStream os = ex.getResponseBody()) { os.write(data); }
    }

    private static void sendJson(HttpExchange ex, int code, String json) throws IOException {
        byte[] data = json.getBytes(StandardCharsets.UTF_8);
        ex.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        ex.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
        ex.sendResponseHeaders(code, data.length);
        try (OutputStream os = ex.getResponseBody()) { os.write(data); }
    }

    private static void send404(HttpExchange ex) throws IOException {
        sendHtml(ex, 404, TemplateEngine.notFound());
    }

    private static void send405(HttpExchange ex) throws IOException {
        ex.sendResponseHeaders(405, -1);
    }
}

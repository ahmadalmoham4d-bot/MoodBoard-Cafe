package com.moodcafe.server;

import com.moodcafe.model.Drink;
import com.moodcafe.service.DrinkService;
import java.util.*;

/**
 * Builds HTML pages as strings — acts like a simple template engine.
 */
public class TemplateEngine {

    private static final String MOOD_ICON(String mood) {
        switch (mood) {
            case "happy":       return "🌞";
            case "sad":         return "🌧️";
            case "energetic":   return "⚡";
            case "stressed":    return "😤";
            case "romantic":    return "💕";
            case "adventurous": return "🌍";
            default:            return "✨";
        }
    }

    private static final String MOOD_DESC(String mood) {
        switch (mood) {
            case "happy":       return "Celebrate the joy";
            case "sad":         return "A comforting hug";
            case "energetic":   return "Fuel the fire";
            case "stressed":    return "Find your calm";
            case "romantic":    return "Set the mood";
            case "adventurous": return "Bold &amp; daring";
            default:            return "Feel it";
        }
    }

    private static String cap(String s) {
        if (s == null || s.isEmpty()) return s;
        return Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }

    // ── Shared layout parts ───────────────────────────────────────────────────

    private static String head(String title) {
        return "<!DOCTYPE html><html lang='en'><head>" +
            "<meta charset='UTF-8'>" +
            "<meta name='viewport' content='width=device-width, initial-scale=1.0'>" +
            "<title>" + title + "</title>" +
            "<link rel='preconnect' href='https://fonts.googleapis.com'>" +
            "<link href='https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;1,400&amp;family=DM+Sans:wght@300;400;500&amp;display=swap' rel='stylesheet'>" +
            "<link rel='stylesheet' href='/css/style.css'>" +
            "</head><body>" +
            "<div class='noise-overlay'></div>" +
            "<nav class='navbar'>" +
            "  <a href='/' class='logo'>☕ MoodBoard Café</a>" +
            "  <div class='nav-links'><a href='/'>Home</a><a href='/menu'>Full Menu</a></div>" +
            "</nav>";
    }

    private static String foot() {
        return "<footer class='footer'>" +
            "<p>☕ MoodBoard Café &mdash; <em>Built with pure Java</em></p>" +
            "<p class='footer-small'>A school project made with care &amp; caffeine</p>" +
            "</footer><script src='/js/main.js'></script></body></html>";
    }

    // ── Home page ─────────────────────────────────────────────────────────────

    public static String homePage(List<String> moods) {
        StringBuilder html = new StringBuilder();
        html.append(head("MoodBoard Café ☕"));

        // Hero
        html.append("<section class='hero'>");
        html.append("<div class='hero-blob blob-1'></div><div class='hero-blob blob-2'></div><div class='hero-blob blob-3'></div>");
        html.append("<div class='hero-content'>");
        html.append("<p class='hero-eyebrow'>Welcome to</p>");
        html.append("<h1 class='hero-title'>MoodBoard<br><em>Café</em></h1>");
        html.append("<p class='hero-subtitle'>Tell us how you feel.<br>We'll craft the perfect drink for your soul.</p>");
        html.append("<a href='#moods' class='btn-primary'>Find My Drink ↓</a>");
        html.append("</div>");
        html.append("<div class='hero-visual'><div class='cup-container'>");
        html.append("<div class='steam s1'></div><div class='steam s2'></div><div class='steam s3'></div>");
        html.append("<div class='cup'>☕</div></div></div>");
        html.append("</section>");

        // Mood section
        html.append("<section class='mood-section' id='moods'><div class='container'>");
        html.append("<h2 class='section-title'>How are you feeling <em>today?</em></h2>");
        html.append("<p class='section-sub'>Pick your vibe and we'll match it with the perfect brew</p>");
        html.append("<div class='mood-grid'>");
        for (String mood : moods) {
            html.append("<a href='/mood/").append(mood).append("' class='mood-card' data-mood='").append(mood).append("'>");
            html.append("<div class='mood-emoji'>").append(MOOD_ICON(mood)).append("</div>");
            html.append("<h3 class='mood-name'>").append(cap(mood)).append("</h3>");
            html.append("<p class='mood-desc'>").append(MOOD_DESC(mood)).append("</p>");
            html.append("<span class='mood-cta'>Explore drinks →</span>");
            html.append("</a>");
        }
        html.append("</div></div></section>");

        // Strip
        html.append("<section class='about-strip'><div class='container strip-inner'>");
        html.append("<div class='strip-item'><span class='strip-icon'>🌿</span><p>18 unique drinks</p></div>");
        html.append("<div class='strip-divider'>·</div>");
        html.append("<div class='strip-item'><span class='strip-icon'>🎲</span><p>Surprise me feature</p></div>");
        html.append("<div class='strip-divider'>·</div>");
        html.append("<div class='strip-item'><span class='strip-icon'>☕</span><p>6 moods covered</p></div>");
        html.append("<div class='strip-divider'>·</div>");
        html.append("<div class='strip-item'><span class='strip-icon'>💫</span><p>All made with love</p></div>");
        html.append("</div></section>");

        html.append(foot());
        return html.toString();
    }

    // ── Drinks page ───────────────────────────────────────────────────────────

    public static String drinksPage(String mood, List<Drink> drinks, List<String> allMoods) {
        StringBuilder html = new StringBuilder();
        html.append(head("Drinks for " + cap(mood) + " · MoodBoard Café"));

        html.append("<section class='page-header'>");
        html.append("<div class='hero-blob blob-1'></div><div class='hero-blob blob-2'></div>");
        html.append("<a href='/' class='back-btn'>← Back</a>");
        html.append("<div class='page-header-content'>");
        html.append("<p class='hero-eyebrow'>Drinks for your mood</p>");
        html.append("<h1 class='hero-title'>").append(MOOD_ICON(mood)).append(" ").append(cap(mood)).append("</h1>");
        html.append("<p class='hero-subtitle'>Here are your perfect matches today</p>");
        html.append("</div></section>");

        html.append("<section class='drinks-section'><div class='container'>");

        // Surprise bar
        html.append("<div class='surprise-bar'>");
        html.append("<p>Can't decide? Let fate choose for you.</p>");
        html.append("<a href='/surprise/").append(mood).append("' class='btn-surprise'>🎲 Surprise Me!</a>");
        html.append("</div>");

        // Drink cards
        html.append("<div class='drinks-grid'>");
        for (Drink d : drinks) {
            html.append("<div class='drink-card' style='--accent:").append(d.getColor()).append("'>");
            html.append("<div class='drink-card-top'>");
            html.append("<div class='drink-emoji'>").append(d.getEmoji()).append("</div>");
            html.append("<div class='drink-color-bar' style='background:").append(d.getColor()).append("'></div>");
            html.append("</div>");
            html.append("<div class='drink-card-body'>");
            html.append("<h3 class='drink-name'>").append(d.getName()).append("</h3>");
            html.append("<p class='drink-desc'>").append(d.getDescription()).append("</p>");
            html.append("<div class='ingredients-box'>");
            html.append("<p class='ingredients-label'>✦ Ingredients</p>");
            html.append("<p class='ingredients-text'>").append(d.getIngredients()).append("</p>");
            html.append("</div></div></div>");
        }
        html.append("</div>");

        // Other moods
        html.append("<div class='other-moods'><h3>Explore another mood</h3><div class='other-moods-list'>");
        for (String m : allMoods) {
            if (!m.equals(mood)) {
                html.append("<a href='/mood/").append(m).append("' class='other-mood-chip'>")
                    .append(MOOD_ICON(m)).append(" ").append(cap(m)).append("</a>");
            }
        }
        html.append("</div></div>");
        html.append("</div></section>");
        html.append(foot());
        return html.toString();
    }

    // ── Surprise page ─────────────────────────────────────────────────────────

    public static String surprisePage(String mood, Drink drink) {
        StringBuilder html = new StringBuilder();
        html.append(head("Your Surprise Drink · MoodBoard Café"));

        html.append("<section class='surprise-page'>");
        html.append("<div class='hero-blob blob-1'></div><div class='hero-blob blob-2'></div>");
        html.append("<div class='container surprise-container'>");
        html.append("<a href='/mood/").append(mood).append("' class='back-btn'>← Back to ").append(cap(mood)).append("</a>");

        if (drink != null) {
            html.append("<div class='surprise-label'>🎲 Today's pick for your <em>").append(mood).append("</em> mood</div>");
            html.append("<div class='big-drink-card' style='--accent:").append(drink.getColor()).append(";border-top-color:").append(drink.getColor()).append("'>");
            html.append("<div class='big-drink-emoji'>").append(drink.getEmoji()).append("</div>");
            html.append("<h1 class='big-drink-name'>").append(drink.getName()).append("</h1>");
            html.append("<p class='big-drink-desc'>").append(drink.getDescription()).append("</p>");
            html.append("<div class='big-ingredients'>");
            html.append("<p class='ingredients-label'>✦ What's inside</p>");
            html.append("<p class='ingredients-text'>").append(drink.getIngredients()).append("</p>");
            html.append("</div>");
            html.append("<div class='surprise-actions'>");
            html.append("<a href='/surprise/").append(mood).append("' class='btn-primary'>🎲 Try Another</a>");
            html.append("<a href='/mood/").append(mood).append("' class='btn-outline'>View All →</a>");
            html.append("</div></div>");
        } else {
            html.append("<p>Hmm, no drink found. <a href='/'>Go home</a>.</p>");
        }

        html.append("</div></section>");
        html.append(foot());
        return html.toString();
    }

    // ── Menu page ─────────────────────────────────────────────────────────────

    public static String menuPage(Map<String, List<Drink>> allDrinks) {
        StringBuilder html = new StringBuilder();
        html.append(head("Full Menu · MoodBoard Café"));

        html.append("<section class='page-header'>");
        html.append("<div class='hero-blob blob-1'></div>");
        html.append("<a href='/' class='back-btn'>← Home</a>");
        html.append("<div class='page-header-content'>");
        html.append("<p class='hero-eyebrow'>Everything we offer</p>");
        html.append("<h1 class='hero-title'>The Full <em>Menu</em></h1>");
        html.append("<p class='hero-subtitle'>18 hand-crafted drinks across 6 moods</p>");
        html.append("</div></section>");

        html.append("<section class='menu-section'><div class='container'>");
        for (Map.Entry<String, List<Drink>> entry : allDrinks.entrySet()) {
            String mood = entry.getKey();
            html.append("<div class='menu-category'>");
            html.append("<div class='menu-category-header'>");
            html.append("<span class='menu-mood-icon'>").append(MOOD_ICON(mood)).append("</span>");
            html.append("<h2 class='menu-mood-name'>").append(cap(mood)).append("</h2>");
            html.append("<a href='/mood/").append(mood).append("' class='menu-see-all'>See all →</a>");
            html.append("</div><div class='menu-drinks-row'>");
            for (Drink d : entry.getValue()) {
                html.append("<div class='menu-drink-item' style='border-left:4px solid ").append(d.getColor()).append("'>");
                html.append("<div class='menu-drink-top'><span class='menu-drink-emoji'>").append(d.getEmoji()).append("</span>");
                html.append("<span class='menu-drink-name'>").append(d.getName()).append("</span></div>");
                html.append("<p class='menu-drink-desc'>").append(d.getDescription()).append("</p>");
                html.append("</div>");
            }
            html.append("</div></div>");
        }
        html.append("</div></section>");
        html.append(foot());
        return html.toString();
    }

    // ── 404 ───────────────────────────────────────────────────────────────────

    public static String notFound() {
        return head("404 · MoodBoard Café") +
            "<section class='surprise-page'><div class='container surprise-container' style='text-align:center;padding-top:120px'>" +
            "<div style='font-size:5rem'>☕</div>" +
            "<h1 class='hero-title' style='margin:24px 0'>404</h1>" +
            "<p class='hero-subtitle'>We spilled that page. Sorry!</p>" +
            "<a href='/' class='btn-primary'>Go Home</a>" +
            "</div></section>" +
            foot();
    }
}

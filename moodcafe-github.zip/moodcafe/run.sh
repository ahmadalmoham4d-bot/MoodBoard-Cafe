#!/bin/bash
# ============================================================
#  MoodBoard Café — Build & Run Script
#  Requirements: Java 11+ (JDK) installed
# ============================================================

JAVAC=$(which javac 2>/dev/null || echo "/usr/lib/jvm/java-21-openjdk-amd64/bin/javac")
JAVA=$(which java 2>/dev/null || echo "/usr/lib/jvm/java-21-openjdk-amd64/bin/java")

echo "╔══════════════════════════════════════╗"
echo "║     ☕  MoodBoard Café Builder        ║"
echo "╚══════════════════════════════════════╝"
echo ""

# Check javac
if ! command -v "$JAVAC" &> /dev/null; then
    echo "❌ Error: javac (Java compiler) not found."
    echo "   Please install a Java JDK (version 11 or newer)."
    echo "   Download: https://adoptium.net/"
    exit 1
fi

echo "✅ Java compiler found: $($JAVAC -version 2>&1)"

# Compile
echo ""
echo "📦 Compiling Java source files..."
mkdir -p out
$JAVAC -d out $(find src -name "*.java")

if [ $? -ne 0 ]; then
    echo "❌ Compilation failed. Check errors above."
    exit 1
fi
echo "✅ Compilation successful!"

# Run
echo ""
echo "🚀 Starting server on http://localhost:8080"
echo "   Press Ctrl+C to stop."
echo ""
$JAVA -cp out com.moodcafe.server.MoodCafeServer

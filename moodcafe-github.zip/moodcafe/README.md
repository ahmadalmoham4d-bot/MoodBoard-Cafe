# ☕ MoodBoard Café
### Full-Stack Java Web Application — Data Structures Project

> A mood-based drink recommendation website built entirely in **pure Java** with zero external libraries or frameworks.

---

## 📋 Project Description

**MoodBoard Café** is a full-stack web application where users select their current mood and receive personalized drink recommendations. The app demonstrates core Java concepts including Object-Oriented Programming, Collections (LinkedHashMap, ArrayList), a built-in HTTP Server, the Singleton design pattern, and a custom MVC architecture — all without using any external frameworks like Spring Boot.

### Features
- 🌞 **6 mood categories** — Happy, Sad, Energetic, Stressed, Romantic, Adventurous
- 🍹 **18 hand-crafted drink recipes** with ingredients
- 🎲 **Surprise Me** — get a random drink for your mood
- 📋 **Full menu** — browse all drinks at once
- 🔌 **REST API** — 4 JSON endpoints
- 📱 **Responsive design** — works on mobile and desktop

### Architecture (MVC Pattern)
```
Browser Request
      ↓
MoodCafeServer.java  (Controller)
Receives HTTP requests, routes URLs to handlers
      ↓                    ↓
DrinkService.java     TemplateEngine.java
   (Service)               (View)
LinkedHashMap         Builds HTML pages
with 18 drinks        as Java Strings
      ↓
Drink.java  (Model)
name, emoji, color, mood...
```

---

## ⚙️ Requirements

### Software
| Requirement | Version | Download |
|-------------|---------|----------|
| Java JDK | 11 or newer (JDK 21 recommended) | https://adoptium.net/ |

### No other dependencies
This project uses **only the Java standard library**. There is no Maven, no Gradle, no Spring Boot, no npm — just plain Java.

### Verify your Java installation
Open a terminal and run:
```bash
java -version
javac -version
```
Both should print a version number. If `javac` is not found, you need a **JDK** (not just a JRE).

---

## 🚀 How to Run

### Option 1 — Automatic Script (Recommended)

**Mac / Linux:**
```bash
chmod +x run.sh
./run.sh
```

**Windows:**
```
Double-click run.bat
```

### Option 2 — Manual Commands

Open a terminal in the project root folder:

```bash
# Step 1: Compile
javac -d out src/com/moodcafe/model/Drink.java src/com/moodcafe/service/DrinkService.java src/com/moodcafe/server/TemplateEngine.java src/com/moodcafe/server/MoodCafeServer.java

# Step 2: Run
java -cp out com.moodcafe.server.MoodCafeServer
```

### Step 3 — Open the app

Once you see this in the terminal:
```
╔══════════════════════════════════════╗
║   ☕  MoodBoard Café is running!      ║
║   Open: http://localhost:8080         ║
╚══════════════════════════════════════╝
```

Open your browser and visit: **http://localhost:8080**

Press `Ctrl + C` to stop the server.

---

## 📁 Project Structure

```
moodcafe/
├── src/
│   └── com/moodcafe/
│       ├── model/
│       │   └── Drink.java              ← Data model (name, emoji, color, ingredients, mood)
│       ├── service/
│       │   └── DrinkService.java       ← Business logic (all 18 drinks, mood lookup, JSON)
│       └── server/
│           ├── MoodCafeServer.java     ← HTTP server + URL router (Controller)
│           └── TemplateEngine.java     ← HTML page builder (View)
├── static/
│   ├── css/style.css                   ← Styles, animations, responsive layout
│   └── js/main.js                      ← Scroll animations, interactions
├── run.sh                              ← Build & run (Mac/Linux)
├── run.bat                             ← Build & run (Windows)
└── README.md                           ← This file
```

---

## 🔌 REST API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/moods` | Returns all 6 mood names as JSON |
| GET | `/api/drinks/{mood}` | Returns 3 drinks for a mood |
| GET | `/api/random/{mood}` | Returns 1 random drink |
| GET | `/api/menu` | Returns all 18 drinks grouped by mood |

Example:
```bash
curl http://localhost:8080/api/drinks/happy
```

---

## 🛠️ Key Java Concepts Used

| Concept | Where |
|---------|-------|
| Classes & Objects (OOP) | `Drink.java` — blueprint for all drink objects |
| Encapsulation | `private final` fields + public getters in `Drink.java` |
| `LinkedHashMap<String, List<Drink>>` | `DrinkService.java` — maps mood name → list of drinks |
| `ArrayList` / `List` | 3 drinks per mood, supports `get(randomIndex)` |
| Singleton Pattern | `DrinkService.getInstance()` — one shared instance |
| Built-in HTTP Server | `com.sun.net.httpserver.HttpServer` — no frameworks needed |
| StringBuilder | `TemplateEngine.java` — builds HTML dynamically |
| File I/O | `Files.readAllBytes()` — serves CSS and JS files |
| `Random` | `nextInt(size)` — random drink selection |
| MVC Architecture | Server=Controller, DrinkService=Model, TemplateEngine=View |

---

## 👤 Author

**Ahmad Al Mohamad**  
Data Structures — Java Project  
May 2026

---

*Built with ☕ and pure Java — zero frameworks, zero dependencies.*

@echo off
echo ============================================
echo     MoodBoard Cafe - Build and Run
echo ============================================
echo.

where javac >nul 2>&1
IF %ERRORLEVEL% NEQ 0 (
    echo ERROR: javac not found. Install a Java JDK first.
    echo Download from: https://adoptium.net/
    pause
    exit /b 1
)

echo Compiling Java files...
if not exist out mkdir out
for /r src %%f in (*.java) do set SOURCES=!SOURCES! "%%f"
javac -d out -sourcepath src src/com/moodcafe/server/MoodCafeServer.java src/com/moodcafe/server/TemplateEngine.java src/com/moodcafe/service/DrinkService.java src/com/moodcafe/model/Drink.java

IF %ERRORLEVEL% NEQ 0 (
    echo Compilation FAILED.
    pause
    exit /b 1
)

echo Compilation successful!
echo.
echo Starting server at http://localhost:8080
echo Press Ctrl+C to stop.
echo.
java -cp out com.moodcafe.server.MoodCafeServer
pause

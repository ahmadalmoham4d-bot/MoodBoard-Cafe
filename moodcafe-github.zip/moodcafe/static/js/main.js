document.addEventListener('DOMContentLoaded', () => {
    const targets = document.querySelectorAll('.mood-card, .drink-card, .menu-drink-item, .menu-category-header, .big-drink-card');
    targets.forEach((el, i) => { el.classList.add('fade-in'); el.style.transitionDelay = `${i * 0.07}s`; });
    const observer = new IntersectionObserver(entries => entries.forEach(e => { if (e.isIntersecting) e.target.classList.add('visible'); }), { threshold: 0.12 });
    targets.forEach(el => observer.observe(el));
    setTimeout(() => targets.forEach(el => { if (el.getBoundingClientRect().top < window.innerHeight) el.classList.add('visible'); }), 100);
});
const navbar = document.querySelector('.navbar');
if (navbar) window.addEventListener('scroll', () => navbar.style.boxShadow = window.scrollY > 30 ? '0 4px 24px rgba(26,18,8,.10)' : 'none');
document.querySelectorAll('.mood-card').forEach(card => {
    const colors = { happy:'#FFB347', sad:'#8BAFD6', energetic:'#FF5722', stressed:'#81C784', romantic:'#E91E8C', adventurous:'#8B4513' };
    const c = colors[card.dataset.mood];
    if (c) { card.addEventListener('mouseenter', () => card.style.borderColor = c); card.addEventListener('mouseleave', () => card.style.borderColor = ''); }
});
const sb = document.querySelector('.btn-surprise');
if (sb) sb.addEventListener('click', () => { sb.textContent = '✨ Picking for you...'; sb.style.background = '#1A1208'; });
console.log('%c☕ MoodBoard Café — Pure Java HTTP Server', 'color:#D4782A;font-family:Georgia,serif;font-size:14px;font-weight:bold');
